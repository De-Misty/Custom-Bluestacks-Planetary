﻿using System;

// Token: 0x02000027 RID: 39
public enum DeviceType
{
	// Token: 0x0400014A RID: 330
	Keyboard,
	// Token: 0x0400014B RID: 331
	Mouse
}
