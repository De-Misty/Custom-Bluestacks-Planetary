﻿using System;

// Token: 0x02000026 RID: 38
public enum Positions
{
	// Token: 0x04000144 RID: 324
	Up,
	// Token: 0x04000145 RID: 325
	Down,
	// Token: 0x04000146 RID: 326
	Left,
	// Token: 0x04000147 RID: 327
	Right,
	// Token: 0x04000148 RID: 328
	Center
}
