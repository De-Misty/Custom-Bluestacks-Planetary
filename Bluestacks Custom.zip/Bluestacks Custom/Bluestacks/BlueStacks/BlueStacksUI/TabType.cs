﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200002E RID: 46
	public enum TabType
	{
		// Token: 0x04000192 RID: 402
		AppTab,
		// Token: 0x04000193 RID: 403
		WebTab,
		// Token: 0x04000194 RID: 404
		HomeTab
	}
}
