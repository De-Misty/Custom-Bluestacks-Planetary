﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003C RID: 60
	[Serializable]
	public class GameAwareOnboardingInfo
	{
		// Token: 0x1700016E RID: 366
		// (get) Token: 0x060003AA RID: 938 RVA: 0x00004642 File Offset: 0x00002842
		// (set) Token: 0x060003AB RID: 939 RVA: 0x0000464A File Offset: 0x0000284A
		public AppPackageListObject GameAwareOnBoardingAppPackages { get; set; }
	}
}
