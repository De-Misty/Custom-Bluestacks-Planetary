﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000066 RID: 102
	[Serializable]
	public class GuidanceEditDecimalModel : GuidanceEditModel
	{
	}
}
