﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003A RID: 58
	[Serializable]
	public class AppSpecificCustomCursorInfo
	{
		// Token: 0x1700016D RID: 365
		// (get) Token: 0x060003A3 RID: 931 RVA: 0x00004631 File Offset: 0x00002831
		// (set) Token: 0x060003A4 RID: 932 RVA: 0x00004639 File Offset: 0x00002839
		public AppPackageListObject CustomCursorAppPackages { get; set; }
	}
}
