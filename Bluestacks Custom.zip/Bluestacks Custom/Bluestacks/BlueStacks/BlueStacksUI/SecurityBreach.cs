﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A4 RID: 164
	public enum SecurityBreach
	{
		// Token: 0x0400038D RID: 909
		SCRIPT_TOOLS,
		// Token: 0x0400038E RID: 910
		DEVICE_PROBED,
		// Token: 0x0400038F RID: 911
		DEVICE_ROOTED,
		// Token: 0x04000390 RID: 912
		DEVICE_PROFILE_CHANGED,
		// Token: 0x04000391 RID: 913
		SYNTHETIC_INPUT
	}
}
