﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004B RID: 75
	public enum InGameResolution
	{
		// Token: 0x04000237 RID: 567
		HD_720p,
		// Token: 0x04000238 RID: 568
		FHD_1080p,
		// Token: 0x04000239 RID: 569
		QHD_1440p,
		// Token: 0x0400023A RID: 570
		UHD_2160p
	}
}
