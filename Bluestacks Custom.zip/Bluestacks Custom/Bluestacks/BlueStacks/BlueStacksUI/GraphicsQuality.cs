﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004C RID: 76
	public enum GraphicsQuality
	{
		// Token: 0x0400023C RID: 572
		Auto,
		// Token: 0x0400023D RID: 573
		Smooth,
		// Token: 0x0400023E RID: 574
		Balanced,
		// Token: 0x0400023F RID: 575
		HD
	}
}
