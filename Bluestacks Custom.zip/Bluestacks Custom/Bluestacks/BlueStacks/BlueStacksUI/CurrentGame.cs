﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004A RID: 74
	public enum CurrentGame
	{
		// Token: 0x04000231 RID: 561
		None,
		// Token: 0x04000232 RID: 562
		PubG,
		// Token: 0x04000233 RID: 563
		CallOfDuty,
		// Token: 0x04000234 RID: 564
		FreeFire,
		// Token: 0x04000235 RID: 565
		OtherApp
	}
}
