﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A1 RID: 161
	public enum QuitActionItemCTA
	{
		// Token: 0x04000380 RID: 896
		OpenLinkInBrowser,
		// Token: 0x04000381 RID: 897
		OpenAppCenter,
		// Token: 0x04000382 RID: 898
		OpenApplication
	}
}
