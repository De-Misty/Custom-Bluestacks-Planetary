﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A0 RID: 160
	public enum QuitActionItem
	{
		// Token: 0x04000376 RID: 886
		None,
		// Token: 0x04000377 RID: 887
		StuckAtBoot,
		// Token: 0x04000378 RID: 888
		SomethingElseWrong,
		// Token: 0x04000379 RID: 889
		SlowPerformance,
		// Token: 0x0400037A RID: 890
		WhyGoogleAccount,
		// Token: 0x0400037B RID: 891
		TroubleSigningIn,
		// Token: 0x0400037C RID: 892
		UnsureWhereStart,
		// Token: 0x0400037D RID: 893
		IssueInstallingGame,
		// Token: 0x0400037E RID: 894
		FacingOtherTroubles
	}
}
