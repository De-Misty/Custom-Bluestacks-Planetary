﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A2 RID: 162
	public enum QuitActionItemProperty
	{
		// Token: 0x04000384 RID: 900
		ImageName,
		// Token: 0x04000385 RID: 901
		BodyText,
		// Token: 0x04000386 RID: 902
		CallToAction,
		// Token: 0x04000387 RID: 903
		ActionText,
		// Token: 0x04000388 RID: 904
		ActionValue,
		// Token: 0x04000389 RID: 905
		StatEventName
	}
}
