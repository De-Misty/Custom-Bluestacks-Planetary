﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200028B RID: 651
	public class PercentageChangedEventArgs : EventArgs
	{
		// Token: 0x17000364 RID: 868
		// (get) Token: 0x0600179D RID: 6045 RVA: 0x0000FE7D File Offset: 0x0000E07D
		// (set) Token: 0x0600179E RID: 6046 RVA: 0x0000FE85 File Offset: 0x0000E085
		public int Percentage { get; set; }
	}
}
