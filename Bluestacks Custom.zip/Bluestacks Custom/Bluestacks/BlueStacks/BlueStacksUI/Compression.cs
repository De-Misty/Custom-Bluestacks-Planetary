﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200026A RID: 618
	public enum Compression : ushort
	{
		// Token: 0x04000DB7 RID: 3511
		Store,
		// Token: 0x04000DB8 RID: 3512
		Deflate = 8
	}
}
