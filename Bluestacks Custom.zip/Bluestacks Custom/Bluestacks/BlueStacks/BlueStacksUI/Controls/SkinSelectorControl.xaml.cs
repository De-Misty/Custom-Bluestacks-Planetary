﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.Controls
{
	// Token: 0x020002BC RID: 700
	public partial class SkinSelectorControl : UserControl
	{
		// Token: 0x060019BE RID: 6590 RVA: 0x00011543 File Offset: 0x0000F743
		public SkinSelectorControl()
		{
			this.InitializeComponent();
		}
	}
}
