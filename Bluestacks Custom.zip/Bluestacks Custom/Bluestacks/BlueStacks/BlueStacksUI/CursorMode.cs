﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000049 RID: 73
	public enum CursorMode
	{
		// Token: 0x0400022E RID: 558
		Normal,
		// Token: 0x0400022F RID: 559
		Custom
	}
}
