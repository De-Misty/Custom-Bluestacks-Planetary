﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200028C RID: 652
	// (Invoke) Token: 0x060017A1 RID: 6049
	public delegate void PercentageChangedEventHandler(object sender, PercentageChangedEventArgs args);
}
