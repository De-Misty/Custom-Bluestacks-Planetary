﻿namespace BlueStacks.BlueStacksUI.Custom
{
	// Token: 0x020002D5 RID: 725
	public partial class FpsNotificationForm : global::System.Windows.Forms.Form
	{
	}
}
