﻿using System;
using System.Collections.Generic;

// Token: 0x02000028 RID: 40
public static class ShowImagesOnOverlay
{
	// Token: 0x17000132 RID: 306
	// (get) Token: 0x06000296 RID: 662 RVA: 0x00003AE4 File Offset: 0x00001CE4
	public static List<string> ListShowImagesForKeys { get; } = new List<string>
	{
		"MouseLButton", "MouseRButton", "MouseMButton", "Left", "Up", "Right", "Down", "GamepadDpadUp", "GamepadDpadDown", "GamepadDpadLeft",
		"GamepadDpadRight"
	};
}
