﻿using System;

// Token: 0x02000025 RID: 37
public enum Direction
{
	// Token: 0x0400013F RID: 319
	Up,
	// Token: 0x04000140 RID: 320
	Down,
	// Token: 0x04000141 RID: 321
	Left,
	// Token: 0x04000142 RID: 322
	Right
}
