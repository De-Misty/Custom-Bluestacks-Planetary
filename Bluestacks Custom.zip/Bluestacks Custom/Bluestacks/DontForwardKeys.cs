﻿using System;

// Token: 0x0200000E RID: 14
[Serializable]
public class DontForwardKeys : IMAction
{
}
